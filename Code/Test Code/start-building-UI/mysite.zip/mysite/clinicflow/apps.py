from django.apps import AppConfig


class ClinicflowConfig(AppConfig):
    name = 'clinicflow'
