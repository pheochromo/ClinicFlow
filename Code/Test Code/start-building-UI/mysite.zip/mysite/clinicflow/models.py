from django.db import models

# Create the connection to the simulation engine

#class Simulate(models.Model):


#class Generate(model.Model):




